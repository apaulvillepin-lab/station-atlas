import { StrictMode } from "react";
import { createRoot } from "react-dom/client";
import { BrowserRouter } from "react-router-dom";
import { RequestsProvider } from "./state/RequestsContext";
import "./index.css";
import App from "./App.tsx";

createRoot(document.getElementById("root")!).render(
  <StrictMode>
    <BrowserRouter>
      <RequestsProvider>
        <App />
      </RequestsProvider>
    </BrowserRouter>
  </StrictMode>
);